number_of_rounds = 3 
even_instruction = 'Answer "yes" if the number is even, otherwise answer "no".'
calc_instruction = 'What is the result of the expression?'
MATH_SIGNS = ('+', '-', '*')
gcd_instruction = "Find the greatest common divisor of given numbers."
min_progression_length, max_progression_length = 5, 10
progression_instruction = 'What number is missing in the progression?'
prime_instruction = 'Answer "yes" if given number is prime. Otherwise answer "no".'
