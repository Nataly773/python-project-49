### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nataly773/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Nataly773/python-project-49/actions)
 https://asciinema.org/connect/ecf5779f-7a24-48ea-8076-63c65da6bbff
 https://asciinema.org/a/F8wxh5fH3j6iyfUw0HAukrpiZ
 https://asciinema.org/a/cvMuK4vLAM4x6f06VL5NlPy4c
 https://asciinema.org/a/g7R7edeOUPG0SvEl82B8MaOpl
 https://asciinema.org/a/SXLJWeri0E6uzuOl7HKiKsj9h